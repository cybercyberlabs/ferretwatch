# Chrome Credential Scanner

This is the Chrome version of the Credential Scanner extension.

## Installation
1. Open Chrome
2. Go to chrome://extensions/
3. Enable "Developer mode"
4. Click "Load unpacked"
5. Select this directory

## Features
- Manifest V3 compatibility
- Service Worker background script
- Chrome-specific API optimizations

For more information, see the main documentation.
