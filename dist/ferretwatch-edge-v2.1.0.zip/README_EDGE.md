# Edge Credential Scanner

This is the Microsoft Edge version of the Credential Scanner extension.

## Installation
1. Open Microsoft Edge
2. Go to edge://extensions/
3. Enable "Developer mode"
4. Click "Load unpacked"
5. Select this directory

## Features
- Manifest V3 compatibility (Chromium-based)
- Edge-specific optimizations
- Full feature compatibility

For more information, see the main documentation.
