# Firefox Credential Scanner

This is the Firefox version of the Credential Scanner extension.

## Installation
1. Open Firefox
2. Go to about:debugging
3. Click "This Firefox"
4. Click "Load Temporary Add-on"
5. Select manifest.json from this directory

## Features
- Full Manifest V2 compatibility
- Native Firefox API support
- Optimized for Firefox performance

For more information, see the main documentation.
